#!/usr/bin/env python3
import subprocess
import shlex
import argparse
import os

def creating_db(multi_fasta_input,db_type):
    if db_type == "n":
        type = "nucl"
    elif db_type == "p":
        type = "prot"
    else:
        print("Wrong File type")
        exit
    command = "makeblastdb -in " + multi_fasta_input+ " -dbtype " + type  # -out " + db_name
    subprocess.call(shlex.split(command))
    #Check datbase using: blastdbcmd -db multi_fasta_input -info

def run_blast_db(input,database,db_type,output):
    blast_command = "blast" + db_type + " -max_hsps 1 -max_target_seqs 1 -outfmt 6 -query " + input + " -db " + database + " -out " + output
    #Saving in tsv format
    # print(blast_command)
    subprocess.call(shlex.split(blast_command))

def parse_outputs(hits_output):
    #Assumption: Blast is run with outfmt ==6 so that it has no metadata and only a tsv output
    hits_dict = {}
    with open(hits_output,"r") as file_handle:
        for line in file_handle:
            columns = line.rstrip("\n").split("\t") #creating a list of values from each column in the line
            if line!="": #Not Empty
                hits_dict.update({columns[0]:columns[1]})
    return hits_dict

def find_orthologs(hits1_dict,hits2_dict,output_file_name):
    output = ""
    ##Compare Results of Blast by parsing and create a new output file
    for sequence1 in hits1_dict.keys():
        sequence2 = hits1_dict[sequence1]
        if sequence2 in hits2_dict.keys(): #checking if sequence 2 exists in the other dictionary
            if hits2_dict[sequence2] == sequence1: #checking if they are orthologs
                output += sequence1 + "\t" + sequence2 + "\n"
    output.rstrip("\n")
    with open(output_file_name,"w+") as out_file:
        out_file.write(output)

def count_hits(filename):
    command = "wc -l " + filename
    counts = subprocess.check_output(command, universal_newlines=True, shell=True)
    return(counts.lstrip().split(" ")[0])

def create_README(input1, input2, blast1_results, blast2_results,ortholog_output):
    readme_file_name = "ssrikrishnan6_README.txt"
    readme_txt = ""
    readme_txt += "Total Blast hits in " + input1 + " = " + count_hits(input1) + "\n"
    readme_txt += "Total Blast hits in " + input2  + " = " + count_hits(input2) + "\n"
    readme_txt += "Total number of orthologs = " + count_hits(ortholog_output)

    with open(readme_file_name,"w+") as out_file:
        out_file.write(readme_txt)

def cleanup(input1,input2):
    for file in os.listdir():
        if (input1+"." in file) or (input2+"." in file):
            os.remove(file)
    os.remove("hits1")
    os.remove("hits2")

parser = argparse.ArgumentParser()
parser.add_argument("-t", "--threads", help="Number of Threads", required=False, type=str, default=1)
parser.add_argument("-o", "--output", help="Output file", required=True, type=str)
parser.add_argument('input_files', help="List of input files", type=argparse.FileType('r'), nargs='+')

args = parser.parse_args()

for file in args.input_files:
    # for line in file
    print(file)



## Final command ./ssrikrishnan6_find_orthologs.py -i1 fam18.fasta -i2 mc58.fasta –t n -o ssrikrishnan6_find_orthologs.output